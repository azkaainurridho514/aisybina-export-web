<?php

namespace App\Http\Controllers\Admin\Concerns;

use Illuminate\Contracts\Pagination\LengthAwarePaginator;

/**
 * Dipakai controller admin yang merender daftar (Blade + paginate).
 */
trait PaginatesAdminList
{
    /**
     * Halaman kosong (mis. setelah hapus data terakhir di halaman ini, atau
     * ?page melewati batas) diarahkan ke halaman terakhir yang masih ada.
     * Mengembalikan null bila halaman tidak kosong.
     */
    protected function lastPageRedirect(LengthAwarePaginator $paginator, string $routeName, array $params = [])
    {
        if ($paginator->isEmpty() && $paginator->currentPage() > 1) {
            return redirect()->route($routeName, array_filter(
                $params + ['page' => $paginator->lastPage()]
            ));
        }

        return null;
    }
}
